// Replace with your own firebase config!
export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyBDsdN3XWM5D2-c_ti5j44GrhMnBHNmSF0',
  authDomain: 'react-native-market-2861b.firebaseapp.com',
  databaseURL: 'https://react-native-market-2861b.firebaseio.com',
  projectId: 'react-native-market-2861b',
  storageBucket: 'react-native-market-2861b.appspot.com',
  messagingSenderId: '878215484396',
  appId: '1:878215484396:web:c36074bccb0b5693b0a6c9',
  measurementId: 'G-317PLP59P2',
}

// Replace with your own IDs! follow the guides here:
// https://docs.expo.io/versions/latest/sdk/google/#using-it-inside-of-the-expo-app
export const ANDROID_GOOGLE_CLIENT_ID =
  '878215484396-4pbcf3tghqe9sa0pvq3fifb5etnn4q6s.apps.googleusercontent.com'
export const IOS_GOOGLE_CLIENT_ID =
  '878215484396-5hiqfjetgvbdck03l0jepdgku6u64erm.apps.googleusercontent.com'

// Replace with your own facebook app ID.
// You can find more information how to generate one here:
// https://docs.expo.io/versions/latest/sdk/facebook/#registering-your-app-with-facebook
export const FACEBOOK_APP_ID = '820370405209413'
